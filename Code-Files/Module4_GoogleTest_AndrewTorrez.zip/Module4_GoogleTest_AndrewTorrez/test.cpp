// Created September 25th 
// by Andrew Torrez
// for CS-405-10428

// Uncomment the next line to use precompiled headers
// #include "pch.h"

// Include Google Test and othe required headers
#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <stdexcept>
#include <algorithm>
//
// The global test environment setup and tear down.
// This class handles any initialization and cleanup needed before/after all tests.
// You should not need to change anything here.
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    // Initialize random seed for generating random numbers in tests
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// Create our test class to house shared data between tests.
// All test cases will inherit from this class and use its SetUp and TearDown.
// You should not need to change anything here.
class CollectionTest : public ::testing::Test
{
protected:
  // Create a smart pointer to hold our collection (vector of int)
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { 
    // Create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { 
    // Erase all elements in the collection, if any remain
    collection->clear();
    // Free the pointer
    collection.reset(nullptr);
  }

  // Helper function to add random values from 0 to 99, 'count' times, to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// NOTE:
// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection's smart pointer is not null when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::SetUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // Check if the collection is created (pointer is valid)
  ASSERT_TRUE(collection);

  // The underlying pointer should not be nullptr
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // The collection should be empty right after creation
  ASSERT_TRUE(collection->empty());

  // If empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}
*/

// Test that adding a single value to an empty collection works
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // The collection should start empty
  ASSERT_TRUE(collection->empty());
  // Add one random value
  add_entries(1);
  // Now the collection should not be empty
  EXPECT_FALSE(collection->empty());
  // The size should be exactly 1
  EXPECT_EQ(collection->size(), 1u);
}

// Test that adding five values to the collection works
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  // Add five random values
  add_entries(5);
  // The size should be 5
  ASSERT_EQ(collection->size(), 5u);
}

// Test that max_size is always greater than or equal to size for various collection sizes
TEST_F(CollectionTest, MaxSizeGESize_For_0_1_5_10) {
  std::vector<int> counts{0,1,5,10};
  for (int c : counts) {
    collection->clear();
    if (c > 0) add_entries(c);
    EXPECT_GE(collection->max_size(), collection->size());
  }
}

// Test that capacity is always greater than or equal to size for various collection sizes
TEST_F(CollectionTest, CapacityGESize_For_0_1_5_10) {
  std::vector<int> counts{0,1,5,10};
  for (int c : counts) {
    collection->clear();
    if (c > 0) add_entries(c);
    EXPECT_GE(collection->capacity(), collection->size());
  }
}

// Test that resizing to a larger size increases the size and possibly capacity
TEST_F(CollectionTest, ResizeIncreasesSize) {
  add_entries(1);
  collection->resize(5);
  EXPECT_EQ(collection->size(), 5u);
  EXPECT_GE(collection->capacity(), 5u);
}

// Test that resizing to a smaller size decreases the size
TEST_F(CollectionTest, ResizeDecreasesSize) {
  add_entries(5);
  collection->resize(2);
  EXPECT_EQ(collection->size(), 2u);
}

// Test that resizing to zero makes the collection empty
TEST_F(CollectionTest, ResizeToZeroMakesEmpty) {
  add_entries(3);
  collection->resize(0);
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0u);
}

// Test that clear() erases all elements in the collection
TEST_F(CollectionTest, ClearErasesAll) {
  add_entries(4);
  collection->clear();
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0u);
}

// Test that erase(begin, end) erases all elements in the collection
TEST_F(CollectionTest, EraseBeginEndErasesAll) {
  add_entries(6);
  collection->erase(collection->begin(), collection->end());
  EXPECT_TRUE(collection->empty());
}

// Test that reserve increases the capacity but does not change the size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
  add_entries(2);
  const auto oldSize = collection->size();
  const auto target = oldSize + 10;
  collection->reserve(target);
  EXPECT_EQ(collection->size(), oldSize);
  EXPECT_GE(collection->capacity(), target);
}

// Test that at() throws std::out_of_range when accessing an invalid index (negative test)
TEST_F(CollectionTest, AtThrowsOutOfRangeOnBadIndex) { // negative test
  // empty vector: any index is out of range
  EXPECT_THROW(collection->at(0), std::out_of_range);
}

// Test that insert maintains order when inserting in the middle of the collection
TEST_F(CollectionTest, InsertMaintainsOrder) {
  collection->push_back(1);
  collection->push_back(3);
  // insert 2 between 1 and 3
  collection->insert(collection->begin()+1, 2);
  ASSERT_EQ(collection->size(), 3u);
  EXPECT_EQ((*collection)[0], 1);
  EXPECT_EQ((*collection)[1], 2);
  EXPECT_EQ((*collection)[2], 3);
}

// Test that reserving more than max_size throws std::length_error (negative test)
TEST_F(CollectionTest, ReserveTooLargeThrowsLengthError) { // negative test
  EXPECT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}
